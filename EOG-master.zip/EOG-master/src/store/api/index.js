import findLocationByLatLng from "./findLocationByLatLng";
import findWeatherbyId from "./findWeatherById";
import fetchDroneData from "./fetchDroneData";

export default {
  findLocationByLatLng,
  findWeatherbyId,
  fetchDroneData
};
